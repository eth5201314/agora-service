package Agora.agora

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AgoraApplication

fun main(args: Array<String>) {
	runApplication<AgoraApplication>(*args)
}
