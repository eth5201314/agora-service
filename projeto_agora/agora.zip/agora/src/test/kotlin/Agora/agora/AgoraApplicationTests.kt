package Agora.agora

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AgoraApplicationTests {

	@Test
	fun contextLoads() {
	}

}
